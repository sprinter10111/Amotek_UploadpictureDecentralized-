﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using System.IO;


namespace img_save.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class ImageController : Controller
    {
       
        [HttpPost("uploadImage")]
        public IActionResult UploadImage(IFormFile imageFile)
        {
            if (imageFile == null || imageFile.Length == 0)
            {
                return BadRequest("No image file provided.");
            }

            //een andere opslag manier zoals azure blob storage zou beter zijn.
            string connectionString = "";            
            var client = new MongoClient(connectionString);

            var database = client.GetDatabase("ImageDB");
            var collection = database.GetCollection<ImageDocument>("ImageCollection");            
            using (var stream = new MemoryStream())
            {
                imageFile.CopyTo(stream);                
                byte[] imageData = stream.ToArray(); 

                var document = new ImageDocument
                {
                    ImageData = imageData
                };               
                collection.InsertOne(document);
                return StatusCode(201, document);
            }     
                

                
        }
    }
}
