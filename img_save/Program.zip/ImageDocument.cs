﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace img_save
{
    public class ImageDocument
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public byte[] ImageData { get; set; }
    }
}
